// init.lua

dofile("util/JSONParser.lua")
dofile("util/CCEffect.lua")

dofile("connection.lua")